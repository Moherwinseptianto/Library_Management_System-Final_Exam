//---------------------------------------------------------------------------

#include <fmx.h>
#include <fstream>
#include <string>
#include <vector>
#include <sstream>
#pragma hdrstop

#include "LoginForm.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.fmx"
TMyLoginForm *MyLoginForm;
//---------------------------------------------------------------------------
__fastcall TMyLoginForm::TMyLoginForm(TComponent* Owner)
	: TForm(Owner)
{
}
//---------------------------------------------------------------------------
std::vector<std::string> parseCommaDelimitedString(std::string line){
	std::vector<std::string> result;
	std::stringstream s_stream(line);

	while(s_stream.good()){
		std::string substr;
		getline(s_stream, substr,',');
		result.push_back(substr);
	}
	return result;
}
//---------------------------------------------------------------------------
const char* converToChartPtr(AnsiString ansiStr){
	return ansiStr.c_str();
}
//---------------------------------------------------------------------------
void __fastcall TMyLoginForm::loginButtonClick(TObject *Sender)
{
	fstream myFile;
	myFile.open("registeredUser.txt",ios::in);

	if(myFile.is_open()){
		std::string line;

		while(getline(myFile,line)){
			std::vector<std::string> parsingLine = parseCommaDelimitedString(line);
			const char* studentID = parsingLine.at(1).c_str();

			//AnsiString editID = id_loginEdit->Text;
			//const char* idString = editID.c_str();

			if(std::strcmp(studentID, converToChartPtr(id_loginEdit->Text))==0){
			   const char* password = parsingLine.at(2).c_str();

			//AnsiString editPass = pass_loginEdit->Text;
			//const char* passString = editPass.c_str();

			   if(std::strcmp(password, converToChartPtr(pass_loginEdit->Text))==0)
					notifLabel->Text = "Success";
			   else
					notifLabel->Text = "Wrong Password";

			}
			else
				notifLabel->Text = "Wrong Username/Password!";

		}

	}

}
//---------------------------------------------------------------------------
