//---------------------------------------------------------------------------

#include <fmx.h>
#include <fstream>
#pragma hdrstop

#include "RegistrationForm.h"

//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.fmx"
TMyRegistrationForm *MyRegistrationForm;
//---------------------------------------------------------------------------
__fastcall TMyRegistrationForm::TMyRegistrationForm(TComponent* Owner)
	: TForm(Owner)
{
}
//---------------------------------------------------------------------------
void __fastcall TMyRegistrationForm::saveButtonClick(TObject *Sender)
{
	fstream myFile;
	myFile.open("registeredUser.txt",ios::app);
	if(myFile.is_open()){

		AnsiString name = nameEdit->Text;
		AnsiString id   = idEdit->Text;
		AnsiString pass = passwordEdit->Text;
		AnsiString mail = mailEdit->Text;

		myFile<<name<<","<<id<<","<<pass<<","<<mail<<"\n";
		myFile.close();
		this->Close();
	}
}
//---------------------------------------------------------------------------
